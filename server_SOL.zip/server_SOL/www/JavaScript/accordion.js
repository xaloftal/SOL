function toggleAccordion(contentId, btnId) {
  var content = document.getElementById(contentId);
  var btn = document.getElementById(btnId);

  // Toggle the accordion content
  content.classList.toggle("show");

}