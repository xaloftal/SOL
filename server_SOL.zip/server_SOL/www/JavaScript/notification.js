function submitAppointment() {
    var selectedDateTime = document.getElementById("appointmentDateTime").value;
    alert("Consulta marcada para: " + selectedDateTime);
}

function submitComplaint() {
    alert("Reclamação respondida");
}

function submitElimination() {
    alert("Conta eliminada");
}



